LAB-3 QUESTION-5
-----------------




package com.capg.lab3;
import java.util.*;

public class QuesWarantee {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		purchase();
	}
	
	private static void purchase(){
		System.out.println("Enter product purchase date month an year :");
		int date=sc.nextInt();
		int month=sc.nextInt();
		int year=sc.nextInt();
		System.out.println("Product warrantee year and month :");
		int year1=sc.nextInt();
		int month1=sc.nextInt();
		
		int year3=year+year1;
		int month3;
		if(month+month1>12){
			month3=month+month1;
			month3-=12;
			year3+=1;
			System.out.println("Warrantee till:"+month3+"/"+year3);
		}
		else if(month+month1<12){
			month3=month+month1;
			year3=year+year1;
			System.out.println("Warrantee till:"+month3+"/"+year3);
		}
		else if((month>12)||(month1>12)){
			System.out.println("Enter valid month");
		}
	}

}
