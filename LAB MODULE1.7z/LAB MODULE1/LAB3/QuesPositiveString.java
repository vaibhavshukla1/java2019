LAB-3 QUESTION-2
-----------------




package com.capg.lab3;
import java.util.Scanner;

public class QuesPositiveString {
	static Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		pos();
	}
	
	public static void pos(){
		int flag=0;
		String str=sc.nextLine();
		int[] a=new int[str.length()];
		String[] str2=str.split("");
		for(int i=0;i<str.length();i++){
			char c=str.charAt(i);
			a[i]=(int)c;
			//System.out.println(a[i]);
		}
		for(int i=0;i<str.length()-1;i++){
			if(a[i]<a[i+1]){
				flag=1;
			}
			else{
				flag=0;
				break;
			}
		}
		if(flag==1){
			System.out.println("true");
		}
		else{
			System.out.println("false");
		}
	}

}
