package com.capg.eleven_two;
@FunctionalInterface
public interface IStringSpace {
	public void space(String c);
	

}
