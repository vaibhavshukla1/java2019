package com.capg.eleven_1;

public @interface FunctionalInterface {

}
