LAB-2 QUESTION-4
-------------------


package com.capg.lab2;

public class MobilePerson1 {
	private String fname;
	private String lname;
	private String gender;
	private String mobno;
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getMobno() {
		return mobno;
	}
	public void setMobno(String mobno) {
		this.mobno = mobno;
	}
	public MobilePerson1(String fname, String lname, String gender, String mobno) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.gender = gender;
		this.mobno = mobno;
	}

}



------------------------------------------------------------------------------------------


package com.capg.lab2;

public class MobilePerson2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MobilePerson1 obj=new MobilePerson1("Vaibhav","Shukla","M","8044916208");
		System.out.println("First Name: "+obj.getFname());
		System.out.println("Last Name: "+obj.getLname());
		System.out.println("Gender: "+obj.getGender());
		System.out.println("Mobile No.: "+obj.getMobno());
		
		obj.setFname("qwerwe");
		obj.setLname("jklgf");
		obj.setGender("F");
		obj.setMobno("8276492193");
		
		System.out.println("First Name: "+obj.getFname());
		System.out.println("Last Name: "+obj.getLname());
		System.out.println("Gender: "+obj.getGender());
		System.out.println("Mobile No.: "+obj.getMobno());
		

	}

}

