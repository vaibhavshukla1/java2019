LAB-2 QUESTION-3
-----------------



package com.capg.lab2;

public class Person1 {
	private String firstn;
	private String lastn;
	private String gender;
	public String getFirstn() {
		return firstn;
	}
	public void setFirstn(String firstn) {
		this.firstn = firstn;
	}
	public String getLastn() {
		return lastn;
	}
	public void setLastn(String lastn) {
		this.lastn = lastn;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Person1(String firstn, String lastn, String gender) {
		super();
		this.firstn = firstn;
		this.lastn = lastn;
		this.gender = gender;
	}

}




--------------------------------------------



package com.capg.lab2;

public class Person2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person1 obj=new Person1("Vaibhav","Shukla","M");
		System.out.println("First name : "+obj.getFirstn());
		System.out.println("Last name : "+obj.getLastn());
		System.out.println("Gender : "+obj.getGender());
		obj.setFirstn("sdsdf");
		obj.setLastn("bfdfg");
		obj.setGender("F");
		System.out.println("First name : "+obj.getFirstn());
		System.out.println("Last name : "+obj.getLastn());
		System.out.println("Gender : "+obj.getGender());
		

	}

}

