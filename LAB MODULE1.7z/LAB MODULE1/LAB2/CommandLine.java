LAB-2 QUESTION-2
----------------


package com.capg.lab2;

public class CommandLine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter a Number : "+args[0]);
		if(Integer.parseInt(args[0])>=0)
		{
			System.out.println("positive");
		}
		else {
			System.out.println("negative");
		}

	}

}
